const Medals = () => {
    const medal = "https://img.freepik.com/free-vector/medal-1_78370-530.jpg?semt=ais_hybrid&w=740&q=80";
    return (
        <>
            <img className={"m-1"} src={medal} alt="Medal" width={"100px"}/>
        </>
    );
}

export default Medals;