const Cups = () => {
    const cups = "https://media.istockphoto.com/id/1168757141/vector/gold-trophy-with-the-name-plate-of-the-winner-of-the-competition.jpg?s=612x612&w=0&k=20&c=ljsP4p0yuJnh4f5jE2VwXfjs96CC0x4zj8CHUoMo39E=";

    return (
      <>
          <img className={"m-1"} src={cups} alt="Cups" width={"100px"}/>
      </>
    );
}

export default Cups;